Yu Liang

This software is architectured as follows. This software can work on grad server.

iptools -This folder hosts the files that are compiled into a static library. 
	image - This folder hosts the files that define an image.
	utility- this folder hosts the files that students store their implemented algorithms.
	
lib- This folder hosts the static libraries associated with this software.

project- This folder hosts the files that will be compiled into executables.
	bin- This folder hosts the binary executables created in the project directory.



*** INSTALATION ***

On Linux

Enter the project directory in terminal and run make

As a result you should get iptool in project/bin directory.

*** FUNCTIONS ***

1. Add intensity: add
Increase the intensity for a gray-level image.

2. gray Binarization: binarize1
Binarize the pixels with the gray threshold.

3. color Binarization: binarize2
Binarize the pixels with the color threshold.

4. 1D smoothing : smooth1

5. 2D smoothing : smooth2

6. edge preserving smoothing : edgesmooth


7. Scaling: Scale
Reduce or expand the heigh and width with two scale factors.
Scaling factor = 2: double height and width of the input image.
Scaling factor = 0.5: half height and width of the input image.

ROI********************

2  # Number of ROI
0 0 100 300 100		# Parameters for ROI1: x, y, sx, sy, T/WS
320 80 150 150 200	# Parameters for ROI2: x, y, sx, sy, T/WS

*** PARAMETERS FILE ***

There are for parameters:
1. the input file name;
2. the output file name;
3. the name of the filter. Use "add", "binarize1 or binarize2", "smooth1, smooth2, edgesmooth" and "scale" for your filters;
4. the value for adding intensity, threshold value for binarize filter, or the scaling factor for scale filter.


*** Run the program: ./iptool parameters.txt


parameters.txt Example:

baboon.ppm baboon_colorthre.ppm binarize2 125 10 10 10
baboon.pgm baboon_graythre.pgm binarize1 125
baboon.pgm baboon_add50.pgm add 50
baboon.pgm baboon_smooth2d.pgm smooth2 20
baboon.pgm baboon_smooth1d.pgm smooth1 20
baboon.pgm baboon_edgesmooth.pgm edgesmooth 100
