#include "utility.h"
#include <strings.h>
#include <string.h>

#define MAXRGB 255
#define MINRGB 0
#define MAX_LEN 256
std::string utility::intToString(int number)
{
   std::stringstream ss;//create a stringstream
   ss << number;//add number to the stream
   return ss.str();//return a string with the contents of the stream
}

int utility::checkValue(int value)
{
	if (value > MAXRGB)
		return MAXRGB;
	if (value < MINRGB)
		return MINRGB;
	return value;
}

/*-----------------------------------------------------------------------**/
void utility::addGrey(image &src, image &tgt, int value)
{

	FILE *fp1;
	char *x;
	char *y;
	char *sx;
	char *sy;
	char *t;
	char str1[MAX_LEN];
	if ((fp1 = fopen("ROI.txt","r")) == NULL) {
		fprintf(stderr, "Can't open file: %s\n", "ROI.txt");
		exit(1);
	}
	tgt.resize(src.getNumberOfRows(), src.getNumberOfColumns());
	for (int i=0; i<src.getNumberOfRows(); i++)
		for (int j=0; j<src.getNumberOfColumns(); j++)
		{
			tgt.setPixel(i,j,checkValue(src.getPixel(i,j)));
		}
    while(fgets(str1,MAX_LEN,fp1) != NULL) {
		x = strtok(str1, " ");
		//src.read(pch);

		y = strtok(NULL, " ");
		//strcpy(outfile, pch);

		sx = strtok(NULL, " ");
		sy = strtok(NULL, " ");
		t = strtok(NULL, " ");
	
        for (int i=atoi(x); i<atoi(x)+atoi(sx); i++)
        {
            for (int j=atoi(y); j<atoi(y)+atoi(sy); j++)
            {
                tgt.setPixel(i,j,checkValue(src.getPixel(i,j)+value));
            }
        }
}}

/*-----------------------------------------------------------------------**/
void utility::binarize(image &src, image &tgt, int threshold)
{
	tgt.resize(src.getNumberOfRows(), src.getNumberOfColumns());
	FILE *fp1;
	char *x;
	char *y;
	char *sx;
	char *sy;
	char *t;
	char str1[MAX_LEN];
	if ((fp1 = fopen("ROI.txt","r")) == NULL) {
		fprintf(stderr, "Can't open file: %s\n", "ROI.txt");
		exit(1);
	}
	tgt.resize(src.getNumberOfRows(), src.getNumberOfColumns());
	for (int i=0; i<src.getNumberOfRows(); i++)
		for (int j=0; j<src.getNumberOfColumns(); j++)
		{
			tgt.setPixel(i,j,checkValue(src.getPixel(i,j)));
			tgt.setPixel(i,j,BLUE,checkValue(src.getPixel(i,j,BLUE)));
			tgt.setPixel(i,j,GREEN,checkValue(src.getPixel(i,j,GREEN)));
		}
	printf("row number:%d\n",src.getNumberOfRows());
	printf("columns number:%d\n", src.getNumberOfColumns());
    while(fgets(str1,MAX_LEN,fp1) != NULL) 
	{
		x = strtok(str1, " ");
		//src.read(pch);

		y = strtok(NULL, " ");
		//strcpy(outfile, pch);

		sx = strtok(NULL, " ");
		sy = strtok(NULL, " ");
		t = strtok(NULL, " ");
			
		for (int i=atoi(x); i<atoi(x)+atoi(sx); i++)
	    	    {
	            	for (int j=atoi(y); j<atoi(y)+atoi(sy); j++)
	           	 {
	             	   	if (src.getPixel(i,j) < threshold)
					tgt.setPixel(i,j,MINRGB);
				else
					tgt.setPixel(i,j,MAXRGB);
	                 }
	            }	
	}
}

void utility::binarize2(image &src, image &tgt, int threshold, int r, int g, int b)
{
	tgt.resize(src.getNumberOfRows(), src.getNumberOfColumns());
	FILE *fp1;
	char *x;
	char *y;
	char *sx;
	char *sy;
	char *t;
	char str1[MAX_LEN];
	if ((fp1 = fopen("ROI.txt","r")) == NULL) {
		fprintf(stderr, "Can't open file: %s\n", "ROI.txt");
		exit(1);
	}
	//tgt.resize(src.getNumberOfRows(), src.getNumberOfColumns());
	for (int i=0; i<src.getNumberOfRows(); i++)
		for (int j=0; j<src.getNumberOfColumns(); j++)
		{
			tgt.setPixel(i,j,checkValue(src.getPixel(i,j)));
			tgt.setPixel(i,j,BLUE,checkValue(src.getPixel(i,j,BLUE)));
			tgt.setPixel(i,j,GREEN,checkValue(src.getPixel(i,j,GREEN)));
		}
    while(fgets(str1,MAX_LEN,fp1) != NULL) 
	{
		x = strtok(str1, " ");
		//src.read(pch);
		y = strtok(NULL, " ");
		//strcpy(outfile, pch);
		sx = strtok(NULL, " ");
		sy = strtok(NULL, " ");
		t = strtok(NULL, " ");
			
		for (int i=atoi(x); i<atoi(x)+atoi(sx); i++)
	    	    {
	            	for (int j=atoi(y); j<atoi(y)+atoi(sy); j++)
	           	 {
	             	int cr = r - tgt.getPixel(i, j, RED);
			int cg = g - tgt.getPixel(i, j, GREEN);
			int cb = b - tgt.getPixel(i, j, BLUE);
			int distance = cr * cr + cg * cg + cb * cb;
			int value = 0; 
			if(distance < threshold*threshold) { 
				 value = 255; 
			}
			tgt.setPixel(i, j, RED, value);
			tgt.setPixel(i, j, GREEN, value);
			tgt.setPixel(i, j, BLUE, value);
	                 }
	            }	
	}
	//fclose(fp1);
}


void utility::Smooth2D(image &src, image &tgt)
{
	
	FILE *fp1;
	char *x;
	char *y;
	char *sx;
	char *sy;
	char *t;
	char str1[MAX_LEN];
	if ((fp1 = fopen("ROI.txt","r")) == NULL)
	 {
		fprintf(stderr, "Can't open file: %s\n", "ROI.txt");
		exit(1);
	}
	tgt.resize(src.getNumberOfRows(), src.getNumberOfColumns());
	for (int i=0; i<src.getNumberOfRows(); i++)
	{
		for (int j=0; j<src.getNumberOfColumns(); j++)
		{
			tgt.setPixel(i,j,checkValue(src.getPixel(i,j)));
		}
	}//printf("ok");
    	while(fgets(str1,MAX_LEN,fp1) != NULL) 
	{
		x = strtok(str1, " ");
		//src.read(pch);

		y = strtok(NULL, " ");
		//strcpy(outfile, pch);

		sx = strtok(NULL, " ");
		sy = strtok(NULL, " ");
		t = strtok(NULL, " ");
//	printf("ok");
		int rows = src.getNumberOfRows();
		int columns = src.getNumberOfColumns();
		int h = (atoi(t) - 1)/2;
	for(int x0 = atoi(x); x0 < atoi(x) + atoi(sx); x0++) 
		{
			for(int y0 = atoi(y); y0 < atoi(y) + atoi(sy); y0++) 
			{
				int x1 = x0-h, x2 = x0+h, y1 = y0 - h, y2 = y0 + h;
				if(x1 < 0 || y1 <0 || x2 >= rows || y2 >= columns) continue;
				int value = 0;
				for(int i = x1; i <= x2; i++) 
				{
					for(int j = y1; j <= y2; j++) 
					{
						value += src.getPixel(i, j);
					}
				}
			
				value = value/(atoi(t)*atoi(t));
				tgt.setPixel(x0,y0,value);
			}
		}
	}
}


void utility::Smooth1D(image &src, image &tgt)
{
	
	FILE *fp1;
	char *x;
	char *y;
	char *sx;
	char *sy;
	char *t;
	char str1[MAX_LEN];
	if ((fp1 = fopen("ROI.txt","r")) == NULL)
	 {
		fprintf(stderr, "Can't open file: %s\n", "ROI.txt");
		exit(1);
	}
	tgt.resize(src.getNumberOfRows(), src.getNumberOfColumns());
	for (int i=0; i<src.getNumberOfRows(); i++)
	{
		for (int j=0; j<src.getNumberOfColumns(); j++)
		{
			tgt.setPixel(i,j,checkValue(src.getPixel(i,j)));
		}
	}//printf("ok");
    	while(fgets(str1,MAX_LEN,fp1) != NULL) 
	{
		x = strtok(str1, " ");
		//src.read(pch);

		y = strtok(NULL, " ");
		//strcpy(outfile, pch);

		sx = strtok(NULL, " ");
		sy = strtok(NULL, " ");
		t = strtok(NULL, " ");
		int h = (atoi(t) - 1)/2;
		for(int x0 = atoi(x); x0 < atoi(x) + atoi(sx); x0++) 
		{
			for(int y0 = atoi(y); y0 < atoi(y) + atoi(sy); y0++) 
			{			
				int x1 = x0-h, x2 = x0+h;
				if(x1 < 0 || x2 >= src.getNumberOfRows()) continue;
				int value = 0;
				for(int i = x1; i <= x2; i++) 
				{
					value += src.getPixel(i, y0);
				}
			
			value = value/atoi(t);
			tgt.setPixel(x0,y0,value);
			}		
		}
	}
}


void utility::EdgeSmooth(image &src, image &tgt, int tws)
{
	
	FILE *fp1;
	char *x;
	char *y;
	char *sx;
	char *sy;
	char *t;
	char str1[MAX_LEN];
	if ((fp1 = fopen("ROI.txt","r")) == NULL)
	 {
		fprintf(stderr, "Can't open file: %s\n", "ROI.txt");
		exit(1);
	}
	tgt.resize(src.getNumberOfRows(), src.getNumberOfColumns());
	for (int i=0; i<src.getNumberOfRows(); i++)
	{
		for (int j=0; j<src.getNumberOfColumns(); j++)
		{
			tgt.setPixel(i,j,checkValue(src.getPixel(i,j)));
		}
	}//printf("ok");
    	while(fgets(str1,MAX_LEN,fp1) != NULL) 
	{
		x = strtok(str1, " ");
		//src.read(pch);

		y = strtok(NULL, " ");
		//strcpy(outfile, pch);

		sx = strtok(NULL, " ");
		sy = strtok(NULL, " ");
		t = strtok(NULL, " ");
//	printf("ok");
		int rows = src.getNumberOfRows();
		int columns = src.getNumberOfColumns();
		int h = (atoi(t) - 1)/2;
	for(int x0 = atoi(x); x0 < atoi(x) + atoi(sx); x0++) 
		{
			for(int y0 = atoi(y); y0 < atoi(y) + atoi(sy); y0++) 
			{
				int x1 = x0-h, x2 = x0+h, y1 = y0 - h, y2 = y0 + h;
				if(x1 < 0 || y1 <0 || x2 >= rows || y2 >= columns) continue;
				int value = 0;
				for(int i = x1; i <= x2; i++) 
				{
					for(int j = y1; j <= y2; j++) 
					{
						value += src.getPixel(i, j);
					}
				}
			
				value = value/(atoi(t)*atoi(t));
				if(abs(src.getPixel(x0,y0)-value)<tws)
					{
						tgt.setPixel(x0,y0,value);
					}
				else
					continue;
			}
		}
	}
}



/*-----------------------------------------------------------------------**/
void utility::scale(image &src, image &tgt, float ratio)
{
	int rows = (int)((float)src.getNumberOfRows() * ratio);
	int cols  = (int)((float)src.getNumberOfColumns() * ratio);
	tgt.resize(rows, cols);
	for (int i=0; i<rows; i++)
	{
		for (int j=0; j<cols; j++)
		{
			/* Map the pixel of new image back to original image */
			int i2 = (int)floor((float)i/ratio);
			int j2 = (int)floor((float)j/ratio);
			if (ratio == 2) {
				/* Directly copy the value */
				tgt.setPixel(i,j,checkValue(src.getPixel(i2,j2)));
			}

			if (ratio == 0.5) {
				/* Average the values of four pixels */
				int value = src.getPixel(i2,j2) + src.getPixel(i2,j2+1) + src.getPixel(i2+1,j2) + src.getPixel(i2+1,j2+1);
				tgt.setPixel(i,j,checkValue(value/4));
			}
		}
	}
}



