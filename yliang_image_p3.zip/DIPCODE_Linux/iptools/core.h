#ifndef CORE_H
#define CORE_H

#include "image/image.h"
#include "utility/utility.h"

#endif



